package br.ufsc.solidity.contracts;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Int256;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.abi.datatypes.generated.Uint8;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.2.0.
 */
public class PaperContract extends Contract {
    private static final String BINARY = "6080604052600b805460ff1916905534801561001a57600080fd5b5060405161075e38038061075e833981016040528051602080830151918301805190939290920191610052916000919085019061008c565b50805161006690600190602084019061008c565b5050600060038190556005805460ff1916905560078190556009819055600a5550610127565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f106100cd57805160ff19168380011785556100fa565b828001600101855582156100fa579182015b828111156100fa5782518255916020019190600101906100df565b5061010692915061010a565b5090565b61012491905b808211156101065760008155600101610110565b90565b610628806101366000396000f3006080604052600436106100b95763ffffffff7c01000000000000000000000000000000000000000000000000000000006000350416630f15f4c081146100be5780630f646017146100d55780634e69d560146100f05780635789c7d014610129578063603daf9a146101415780637faf6b16146101cb5780638d56bd94146101e35780639481da531461020a578063ca7a82bd1461021f578063e4173b2c14610234578063e4a302c0146102cd578063fa0c151314610326575b600080fd5b3480156100ca57600080fd5b506100d361033b565b005b3480156100e157600080fd5b506100d3600435602435610351565b3480156100fc57600080fd5b5061010561036b565b6040518082600381111561011557fe5b60ff16815260200191505060405180910390f35b34801561013557600080fd5b506100d3600435610375565b34801561014d57600080fd5b50610156610382565b6040805160208082528351818301528351919283929083019185019080838360005b83811015610190578181015183820152602001610178565b50505050905090810190601f1680156101bd5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b3480156101d757600080fd5b506100d3600435610417565b3480156101ef57600080fd5b506101f861041c565b60408051918252519081900360200190f35b34801561021657600080fd5b506101f8610422565b34801561022b57600080fd5b506100d3610428565b34801561024057600080fd5b506040805160206004803580820135601f81018490048402850184019095528484526100d394369492936024939284019190819084018382808284375050604080516020601f89358b018035918201839004830284018301909452808352979a999881019791965091820194509250829150840183828082843750949750509335945061043c9350505050565b3480156102d957600080fd5b506040805160206004803580820135601f81018490048402850184019095528484526100d39436949293602493928401919081908401838280828437509497506104d19650505050505050565b34801561033257600080fd5b506101566104e4565b600580546001919060ff191682805b0217905550565b6008546001190182116103675760088054820190555b5050565b60055460ff165b90565b6007819055600a01600855565b60018054604080516020601f6002600019610100878916150201909516949094049384018190048102820181019092528281526060939092909183018282801561040d5780601f106103e25761010080835404028352916020019161040d565b820191906000526020600020905b8154815290600101906020018083116103f057829003601f168201915b5050505050905090565b600655565b60065490565b60035490565b600580546003919060ff191660018361034a565b610444610542565b8381526020808201849052604082018390526004805460018101808355600092909252835180519293859360039093027f8a35acfbc15ff81a39ae7d344fd709f28e8600b4aa8c65c6b64bfe7fe36bd19b01926104a49284920190610564565b5060208281015180516104bd9260018501920190610564565b506040820151816002015550505050505050565b8051610367906002906020840190610564565b60028054604080516020601f600019610100600187161502019094168590049384018190048102820181019092528281526060939092909183018282801561040d5780601f106103e25761010080835404028352916020019161040d565b6060604051908101604052806060815260200160608152602001600081525090565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f106105a557805160ff19168380011785556105d2565b828001600101855582156105d2579182015b828111156105d25782518255916020019190600101906105b7565b506105de9291506105e2565b5090565b61037291905b808211156105de57600081556001016105e85600a165627a7a72305820b34e797d508c0eaa17530438c4eafb91178bf5404ae157ef16c3b9be07a8ae540029";

    public static final String FUNC_ACTIVATE = "activate";

    public static final String FUNC_NOTIFIESDELAY = "notifiesDelay";

    public static final String FUNC_GETSTATUS = "getStatus";

    public static final String FUNC_SETSOLICITATIONDAY = "setSolicitationDay";

    public static final String FUNC_GETBUYER = "getBuyer";

    public static final String FUNC_SETEFFECTIVEDAY = "setEffectiveDay";

    public static final String FUNC_GETEFFECTIVEDAY = "getEffectiveDay";

    public static final String FUNC_GETCONTRACTTOTALPRICE = "getContractTotalPrice";

    public static final String FUNC_UNSUCCESSFULTERMINATE = "unsuccessfulTerminate";

    public static final String FUNC_ADDPRODUCT = "addProduct";

    public static final String FUNC_SETBUYERADDRESS = "setBuyerAddress";

    public static final String FUNC_GETBUYERADDRESS = "getBuyerAddress";

    @Deprecated
    protected PaperContract(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected PaperContract(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected PaperContract(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected PaperContract(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteCall<TransactionReceipt> activate() {
        final Function function = new Function(
                FUNC_ACTIVATE, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> notifiesDelay(BigInteger notificationDay, BigInteger delay) {
        final Function function = new Function(
                FUNC_NOTIFIESDELAY, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(notificationDay), 
                new org.web3j.abi.datatypes.generated.Uint256(delay)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<BigInteger> getStatus() {
        final Function function = new Function(FUNC_GETSTATUS, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint8>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<TransactionReceipt> setSolicitationDay(BigInteger _solicitationDay) {
        final Function function = new Function(
                FUNC_SETSOLICITATIONDAY, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(_solicitationDay)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> getBuyer() {
        final Function function = new Function(FUNC_GETBUYER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> setEffectiveDay(BigInteger _effectiveDay) {
        final Function function = new Function(
                FUNC_SETEFFECTIVEDAY, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(_effectiveDay)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<BigInteger> getEffectiveDay() {
        final Function function = new Function(FUNC_GETEFFECTIVEDAY, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> getContractTotalPrice() {
        final Function function = new Function(FUNC_GETCONTRACTTOTALPRICE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Int256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<TransactionReceipt> unsuccessfulTerminate() {
        final Function function = new Function(
                FUNC_UNSUCCESSFULTERMINATE, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> addProduct(String name, String group, BigInteger quantity) {
        final Function function = new Function(
                FUNC_ADDPRODUCT, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(name), 
                new org.web3j.abi.datatypes.Utf8String(group), 
                new org.web3j.abi.datatypes.generated.Int256(quantity)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> setBuyerAddress(String _buyerAddress) {
        final Function function = new Function(
                FUNC_SETBUYERADDRESS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_buyerAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> getBuyerAddress() {
        final Function function = new Function(FUNC_GETBUYERADDRESS, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    @Deprecated
    public static PaperContract load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new PaperContract(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static PaperContract load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new PaperContract(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static PaperContract load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new PaperContract(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static PaperContract load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new PaperContract(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<PaperContract> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider, String _seller, String _buyer) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_seller), 
                new org.web3j.abi.datatypes.Utf8String(_buyer)));
        return deployRemoteCall(PaperContract.class, web3j, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<PaperContract> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider, String _seller, String _buyer) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_seller), 
                new org.web3j.abi.datatypes.Utf8String(_buyer)));
        return deployRemoteCall(PaperContract.class, web3j, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }

    @Deprecated
    public static RemoteCall<PaperContract> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit, String _seller, String _buyer) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_seller), 
                new org.web3j.abi.datatypes.Utf8String(_buyer)));
        return deployRemoteCall(PaperContract.class, web3j, credentials, gasPrice, gasLimit, BINARY, encodedConstructor);
    }

    @Deprecated
    public static RemoteCall<PaperContract> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit, String _seller, String _buyer) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_seller), 
                new org.web3j.abi.datatypes.Utf8String(_buyer)));
        return deployRemoteCall(PaperContract.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, encodedConstructor);
    }
}
