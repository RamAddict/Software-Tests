package interfaces;

public interface IVendido extends ILeiloavel {
	public String getCpfComprador();
}